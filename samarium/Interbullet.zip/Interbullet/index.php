<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="./css/style.css">
        <title>Interbullet Studios</title>
    </head>
    <body>
        <div class="background-left"></div>
        <div class="background-right"></div>
        <div class="navbar">
            
        </div>
        <div class="body">
            <img src="./images/logo.png" alt="logo">
            <h1>Interbullet Studios</h1>
        </div>
    </body>
</html>